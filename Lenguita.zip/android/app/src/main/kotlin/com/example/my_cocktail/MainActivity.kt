package com.example.my_cocktail

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

const kMainUrl = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=";
const kRandomUrl = "https://www.thecocktaildb.com/api/json/v1/1/random.php";

const kBackgroundColor = Color(0xff0d0d0d);
const kComponentColor = Color(0xff381e6e);
const kGroupBackgroundColor = Color(0xff180747);

const kHeaderTextStyle = TextStyle(
  fontSize: 30,
  fontWeight: FontWeight.w700,
);

const kTableTextStyle = TextStyle(
  fontSize: 20,
  fontWeight: FontWeight.w500,
);

const kBorderSide = BorderSide(
  color: kComponentColor,
  width: 5,
);

const kBoxDecorationStyle = BoxDecoration(
  color: kGroupBackgroundColor,
  borderRadius: BorderRadius.all(
    Radius.circular(30),
  ),
);

const kButtonMinSize = Size(100, 55);

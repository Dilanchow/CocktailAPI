import 'package:flutter/material.dart';

class Ingredient {
  Ingredient({@required this.name, @required this.mesure});

  String name;
  String mesure;
}
